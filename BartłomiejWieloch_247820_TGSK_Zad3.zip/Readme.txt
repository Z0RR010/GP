1. Visual Studio 2022 17.4.1
2. glfw 3.3.8 https://github.com/glfw/glfw
3. glm 0.9.9.8 https://github.com/g-truc/glm
4. imgui 1.88 https://github.com/ocornut/imgui
5. stb_image 2.19 https://github.com/nothings/stb/blob/master/stb_image.h
6. glad 0.1.27 https://github.com/Dav1dde/glad
7. spdlog 1.10.0 https://github.com/gabime/spdlog
8. assimp 5.4.3 https://github.com/assimp/assimp